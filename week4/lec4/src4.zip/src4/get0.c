// Gets an int from user using get_int

#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int n = get_int("n: ");
    printf("n: %i\n", n);
}
